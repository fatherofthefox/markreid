import { Layout } from "@/components/layout/layout";
import { FadeUp, Stagger, StaggerItem } from "@/components/ui/animate";
import { Link } from "wouter";
import { ArrowRight } from "lucide-react";

const TIMELINE = [
  { year: "Present", role: "Independent Advisory", desc: "Working with a focused portfolio of B2B companies on sales leadership, GTM strategy, and methodology implementation." },
  { year: "2020–24", role: "VP Sales, SaaS scale-up", desc: "Built revenue motion from seed-stage chaos to a predictable, scalable team of AEs and SDRs. Implemented MEDDIC qualification end-to-end." },
  { year: "2016–20", role: "Head of Enterprise Sales", desc: "Led the enterprise segment. Doubled ACVs through rigorous qualification and Challenger-led discovery. Introduced pipeline review cadence that became company standard." },
  { year: "2013–16", role: "Senior Account Executive", desc: "Top performer across three consecutive years. Consistently 130%+ of quota. Used SPIN and FAINT frameworks in complex multi-stakeholder deals." },
  { year: "2009–13", role: "Business Development & Early Careers", desc: "Learned the craft. Did the reps. Made every mistake early, which is where you want to make them." },
];

export default function About() {
  return (
    <Layout>
      <div className="container mx-auto px-6 py-24 md:py-32 max-w-5xl">
        <FadeUp className="max-w-3xl mb-20">
          <h1 className="text-sm font-mono text-primary uppercase tracking-widest mb-6">About</h1>
          <h2 className="text-4xl md:text-6xl font-serif font-bold mb-8 text-foreground leading-tight">
            Mark Reid.
          </h2>
          <p className="text-xl text-muted-foreground leading-relaxed font-light mb-6">
            Sales leader, advisor, and one of the few people who genuinely enjoys a properly structured pipeline review.
          </p>
          <p className="text-muted-foreground leading-relaxed mb-6">
            I've spent the better part of fifteen years in B2B sales — first as an individual contributor, then leading teams, then building revenue organisations from the ground up. Along the way I've made most of the mistakes you can make, learned which frameworks actually hold up under pressure, and developed a clear opinion on what separates sales teams that perform from those that hope.
          </p>
          <p className="text-muted-foreground leading-relaxed">
            My advisory work is grounded in practice, not theory. I work with a small number of companies at any given time — typically Series A through C SaaS businesses — focused on the three things that consistently move the needle: qualification rigour, team design, and sales culture. I don't do slide decks that sit in a shared drive. I work in the room.
          </p>
        </FadeUp>

        {/* Timeline */}
        <FadeUp className="mb-6">
          <h3 className="text-sm font-mono text-primary uppercase tracking-widest">Career Timeline</h3>
        </FadeUp>

        <Stagger className="space-y-0 mb-32 max-w-3xl" threshold={0.05}>
          {TIMELINE.map(({ year, role, desc }, i) => (
            <StaggerItem key={year}>
              <div className="group flex gap-8 py-8 border-b border-border last:border-0">
                <div className="w-20 shrink-0 text-sm font-mono text-muted-foreground pt-0.5">{year}</div>
                <div>
                  <h4 className="font-serif font-bold text-foreground text-lg mb-2 group-hover:text-primary transition-colors">{role}</h4>
                  <p className="text-muted-foreground text-sm leading-relaxed">{desc}</p>
                </div>
              </div>
            </StaggerItem>
          ))}
        </Stagger>

        {/* Philosophy */}
        <FadeUp className="max-w-3xl mb-20">
          <h3 className="text-sm font-mono text-primary uppercase tracking-widest mb-6">How I think about sales</h3>
          <div className="space-y-6 text-muted-foreground leading-relaxed">
            <p>
              Sales is one of the most learnable skills in business — and one of the most frequently undertaught. Most sales training is surface-level: scripts, objection handling, closing techniques. None of it works sustainably because it doesn't address the underlying problem.
            </p>
            <p>
              The underlying problem is usually one of three things: reps qualifying too loosely, managers reviewing pipeline without sufficient rigour, or leaders designing incentives that reward the wrong behaviour. Fix those three things and performance follows.
            </p>
            <p>
              The frameworks I use — MEDDIC, FAINT, Challenger, SPIN, PEEMEES — aren't magic. They work because they force reps to get uncomfortable and ask questions they'd rather avoid. That discomfort is the job.
            </p>
          </div>
        </FadeUp>

        <FadeUp>
          <div className="flex flex-col sm:flex-row gap-4">
            <Link href="/frameworks" className="inline-flex items-center gap-2 px-6 py-3 bg-primary text-primary-foreground font-semibold hover:bg-primary/90 transition-colors">
              My frameworks <ArrowRight className="w-4 h-4" />
            </Link>
            <Link href="/advisory" className="inline-flex items-center gap-2 px-6 py-3 border border-border text-foreground hover:border-primary/40 transition-colors">
              Advisory work
            </Link>
          </div>
        </FadeUp>
      </div>
    </Layout>
  );
}
