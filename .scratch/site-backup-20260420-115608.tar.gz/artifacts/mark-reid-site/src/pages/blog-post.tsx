import { useState, useEffect } from "react";
import { useRoute, Link } from "wouter";
import { Layout } from "@/components/layout/layout";
import { FadeUp } from "@/components/ui/animate";
import { ArrowLeft } from "lucide-react";

const FALLBACK_POSTS: Record<string, { title: string; date: string; readTime: string; body: string }> = {
  "pipeline-reviews": {
    title: "Why Most Pipeline Reviews Are a Waste of Time",
    date: "March 18, 2024",
    readTime: "7 min read",
    body: `Most pipeline reviews are status updates with a different name. The manager asks "where are we on this?" and the rep gives the most optimistic version of events. Nobody pushes back. The deal moves to the next stage because nobody can afford an awkward conversation. Three weeks later, the deal is still in the same stage.

A real pipeline review is a structured interrogation of deal quality. Not of the rep — of the deal. There's a meaningful difference. The questions you're asking should be about what's been validated versus what's been assumed.

Here are the questions that actually matter:

**On qualification:** Can the rep point to an explicit conversation where the economic buyer has acknowledged the pain and the budget? Or are we assuming they're involved because their name was mentioned in a meeting?

**On process:** Does the rep know exactly what happens between now and close — the actual steps, the people involved, the likely objections at each stage? Or is "close" just an event that might happen at the end of next quarter?

**On the champion:** Has the champion demonstrated that they can mobilise internal support? Have they actually fought for this deal internally, or are they just friendly and enthusiastic in calls?

**On risk:** What is the most likely reason this deal doesn't close? The manager who hasn't asked this question in every pipeline review isn't doing their job.

The pipeline review that changes behaviour is uncomfortable. It should be harder to present a poorly-qualified deal than a well-qualified one. When it isn't, pipeline becomes a vanity metric.

Start there. Fix the review before you fix anything else.`,
  },
  "the-champion-problem": {
    title: "The Champion Problem: How Deals Die Quietly",
    date: "February 4, 2024",
    readTime: "6 min read",
    body: `The most misused word in enterprise sales is "champion." Reps use it to describe anyone who seems positive, enthusiastic, and willing to take meetings. That's not a champion. That's a contact.

A champion is someone who can and will mobilise internal support for your deal when you're not in the room. The distinction is enormous — and the time to find out which one you have is not the week before the expected close date.

Here's how to test whether you actually have a champion:

**Have they given you insider information?** Genuine champions share things they probably shouldn't — internal politics, who's actually blocking progress, what the real budget number is, what competing priorities are. If every conversation is pleasantly surface-level, be worried.

**Have they asked you to help them sell internally?** Champions need tools to make the case to their colleagues. If they've never asked you for a business case, an ROI model, or help preparing for an internal meeting, they're not advocating.

**Have they demonstrated actual advocacy?** Have they arranged a meeting with someone senior that wouldn't otherwise have happened? Have they defended your solution when a colleague raised an objection? Have they followed up on something without being prompted? These are the signals.

The harsh truth is that many reps confuse likeability with influence. A contact who loves your product and is incapable of getting budget approved is a lovely person to talk to and a dead end for your deal.

MEDDIC forces you to identify a champion — but more importantly, it forces you to validate that they're real. The champion letter is the most important one to get right.`,
  },
};

function formatDate(dateStr: string) {
  try {
    return new Date(dateStr).toLocaleDateString("en-GB", { day: "numeric", month: "long", year: "numeric" });
  } catch {
    return dateStr;
  }
}

export default function BlogPost() {
  const [, params] = useRoute("/blog/:slug");
  const slug = params?.slug ?? "";

  const [post, setPost] = useState<{ title: string; date: string; readTime?: string; body: string } | null>(null);
  const [notFound, setNotFound] = useState(false);

  useEffect(() => {
    if (!slug) return;
    fetch(`/api/public/posts/${slug}`)
      .then(r => {
        if (r.status === 404) throw new Error("not found");
        return r.ok ? r.json() : null;
      })
      .then((data: any) => {
        if (data) {
          setPost({
            title: data.title,
            date: formatDate(data.createdAt),
            readTime: data.readTime,
            body: data.body,
          });
        } else {
          // Try fallback
          const fallback = FALLBACK_POSTS[slug];
          if (fallback) setPost(fallback);
          else setNotFound(true);
        }
      })
      .catch(() => {
        const fallback = FALLBACK_POSTS[slug];
        if (fallback) setPost(fallback);
        else setNotFound(true);
      });
  }, [slug]);

  if (notFound) {
    return (
      <Layout>
        <div className="container mx-auto px-6 py-32 text-center">
          <h1 className="text-4xl font-serif font-bold mb-4">Post not found</h1>
          <Link href="/blog" className="text-primary hover:text-primary/70 transition-colors">← Back to writing</Link>
        </div>
      </Layout>
    );
  }

  if (!post) {
    return (
      <Layout>
        <div className="container mx-auto px-6 py-32 flex items-center justify-center">
          <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin" />
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="container mx-auto px-6 py-24 md:py-32 max-w-3xl">
        <FadeUp>
          <Link href="/blog" className="inline-flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors text-sm mb-16">
            <ArrowLeft className="w-4 h-4" /> Back to writing
          </Link>

          <div className="flex items-center gap-4 text-sm font-mono text-muted-foreground mb-8">
            <time>{post.date}</time>
            {post.readTime && (
              <>
                <span className="text-border">•</span>
                <span>{post.readTime}</span>
              </>
            )}
          </div>

          <h1 className="text-4xl md:text-5xl font-serif font-bold text-foreground leading-tight mb-16">
            {post.title}
          </h1>

          <div className="prose prose-lg prose-invert max-w-none text-muted-foreground leading-relaxed space-y-6">
            {post.body.split("\n\n").map((para, i) => {
              if (para.startsWith("**") && para.endsWith("**")) {
                return <h3 key={i} className="text-xl font-serif font-bold text-foreground mt-10 mb-4">{para.replace(/\*\*/g, "")}</h3>;
              }
              if (para.includes("**")) {
                const parts = para.split(/(\*\*[^*]+\*\*)/g);
                return (
                  <p key={i}>
                    {parts.map((part, j) =>
                      part.startsWith("**") ? (
                        <strong key={j} className="text-foreground font-semibold">{part.replace(/\*\*/g, "")}</strong>
                      ) : (
                        part
                      )
                    )}
                  </p>
                );
              }
              return <p key={i}>{para}</p>;
            })}
          </div>
        </FadeUp>
      </div>
    </Layout>
  );
}
