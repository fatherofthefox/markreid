import { Layout } from "@/components/layout/layout";
import { FadeUp, Stagger, StaggerItem } from "@/components/ui/animate";
import { Link } from "wouter";
import { ArrowRight, Mic, Linkedin, BookOpen } from "lucide-react";

const CONTENT_TYPES = [
  {
    icon: BookOpen,
    title: "Essays & Writing",
    desc: "Occasional long-form pieces on sales leadership, methodology, and building high-performance revenue teams. Written when I have something worth saying.",
    href: "/blog",
    cta: "Read the writing",
  },
  {
    icon: Mic,
    title: "Speaking & Podcasts",
    desc: "Available for conference keynotes, workshops, and podcast conversations focused on sales methodology, GTM strategy, and revenue leadership for B2B SaaS businesses.",
    href: "/advisory",
    cta: "Get in touch",
  },
  {
    icon: Linkedin,
    title: "LinkedIn",
    desc: "Shorter thoughts on sales, qualification, pipeline management, and the occasional unpopular opinion about common sales practices.",
    href: "https://linkedin.com/in/markreid",
    cta: "Follow on LinkedIn",
  },
];

const FEATURED_TOPICS = [
  "Why MEDDIC fails when qualification isn't a team habit",
  "The pipeline review that actually changes behaviour",
  "Building sales culture that survives a bad quarter",
  "FAINT vs MEDDIC — when to use each and why",
  "What comp plans teach reps without anyone saying a word",
  "The champion problem: why deals die quietly",
];

export default function Content() {
  return (
    <Layout>
      <div className="container mx-auto px-6 py-24 md:py-32">
        <FadeUp className="max-w-3xl mb-20">
          <h1 className="text-sm font-mono text-primary uppercase tracking-widest mb-6">Content</h1>
          <h2 className="text-4xl md:text-6xl font-serif font-bold mb-8 text-foreground leading-tight">
            Where to find the thinking.
          </h2>
          <p className="text-xl text-muted-foreground leading-relaxed font-light">
            I write, speak, and occasionally appear on podcasts about sales leadership, methodology, and the realities of building revenue teams. Here's where to find it.
          </p>
        </FadeUp>

        <Stagger className="grid gap-8 max-w-5xl md:grid-cols-3 mb-32" threshold={0.05}>
          {CONTENT_TYPES.map(({ icon: Icon, title, desc, href, cta }) => (
            <StaggerItem key={title}>
              <div className="group border border-border p-8 bg-[#0d0d14] hover:border-primary/30 transition-all duration-300 h-full flex flex-col relative overflow-hidden">
                <div className="absolute left-0 top-0 bottom-0 w-0.5 bg-primary scale-y-0 group-hover:scale-y-100 transition-transform duration-400 origin-top" />
                <div className="bg-primary/10 border border-primary/20 p-3 w-fit rounded-sm mb-6">
                  <Icon className="w-5 h-5 text-primary" />
                </div>
                <h3 className="font-serif font-bold text-foreground text-xl mb-3">{title}</h3>
                <p className="text-muted-foreground leading-relaxed mb-6 flex-1">{desc}</p>
                {href.startsWith("http") ? (
                  <a
                    href={href}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-2 text-primary text-sm font-medium hover:text-primary/70 transition-colors"
                  >
                    {cta} <ArrowRight className="w-4 h-4" />
                  </a>
                ) : (
                  <Link href={href} className="inline-flex items-center gap-2 text-primary text-sm font-medium hover:text-primary/70 transition-colors">
                    {cta} <ArrowRight className="w-4 h-4" />
                  </Link>
                )}
              </div>
            </StaggerItem>
          ))}
        </Stagger>

        {/* Topics */}
        <div className="max-w-3xl">
          <FadeUp>
            <h3 className="text-sm font-mono text-primary uppercase tracking-widest mb-8">Topics I return to</h3>
          </FadeUp>
          <Stagger className="grid sm:grid-cols-2 gap-3" threshold={0.05}>
            {FEATURED_TOPICS.map((topic) => (
              <StaggerItem key={topic}>
                <div className="border border-border px-5 py-4 text-sm text-muted-foreground hover:text-foreground hover:border-primary/30 transition-colors duration-200">
                  {topic}
                </div>
              </StaggerItem>
            ))}
          </Stagger>
        </div>
      </div>
    </Layout>
  );
}
