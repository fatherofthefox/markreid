import { Layout } from "@/components/layout/layout";
import { FadeUp, Stagger, StaggerItem } from "@/components/ui/animate";
import { motion } from "framer-motion";
import { CheckCircle, ArrowRight } from "lucide-react";
import { Link } from "wouter";

const SERVICES = [
  {
    title: "Sales methodology implementation",
    desc: "Embedding MEDDIC, Challenger, or SPIN into the day-to-day operating rhythm of your team — not as a training event, but as lived practice. Includes deal coaching, pipeline review redesign, and manager training.",
  },
  {
    title: "GTM strategy and structuring",
    desc: "Defining the ideal customer profile, designing the coverage model, and building the hiring and onboarding sequence that produces consistent ramp times. Particularly useful at the Series A–C inflection point.",
  },
  {
    title: "Revenue leadership coaching",
    desc: "Working directly with heads of sales and VPs on the skills that don't appear in the job spec: running a pipeline review that changes behaviour, delivering feedback that sticks, managing a board conversation on forecast.",
  },
  {
    title: "Team diagnostic and build plan",
    desc: "A structured assessment of what's broken — quota distribution, comp design, ramp performance, qualification standards — followed by a prioritised action plan. Not a slide deck. A working document with owners and dates.",
  },
];

const INCLUDED = [
  "Direct access — no account manager between us",
  "Work in your CRM, your calls, your pipeline reviews",
  "Structured monthly check-ins with async availability",
  "Framework documentation tailored to your context",
  "Introductions where relevant and genuinely useful",
];

export default function Advisory() {
  return (
    <Layout>
      <div className="container mx-auto px-6 py-24 md:py-32 max-w-5xl">
        <FadeUp className="max-w-3xl mb-20">
          <h1 className="text-sm font-mono text-primary uppercase tracking-widest mb-6">Advisory</h1>
          <h2 className="text-4xl md:text-6xl font-serif font-bold mb-8 text-foreground leading-tight">
            Revenue leadership,<br />applied.
          </h2>
          <p className="text-xl text-muted-foreground leading-relaxed font-light mb-6">
            I work with a small number of B2B companies at any given time. Advisory is structured around specific outcomes, not a retainer that drifts.
          </p>
          <p className="text-muted-foreground leading-relaxed">
            Typically Series A through C SaaS businesses where the sales motion is becoming established but qualification rigour, forecast accuracy, or team design is limiting growth. If that describes you, this is the right conversation to have.
          </p>
        </FadeUp>

        {/* Services */}
        <FadeUp className="mb-8">
          <h3 className="text-sm font-mono text-primary uppercase tracking-widest">Areas of work</h3>
        </FadeUp>

        <Stagger className="space-y-6 mb-32" threshold={0.05}>
          {SERVICES.map(({ title, desc }) => (
            <StaggerItem key={title}>
              <motion.div
                className="group border border-border p-8 bg-[#0d0d14] hover:border-primary/30 transition-colors duration-300 relative overflow-hidden"
                whileHover={{ x: 4 }}
                transition={{ duration: 0.2 }}
              >
                <div className="absolute left-0 top-0 bottom-0 w-0.5 bg-primary scale-y-0 group-hover:scale-y-100 transition-transform duration-400 origin-top" />
                <h4 className="font-serif font-bold text-foreground text-xl mb-3">{title}</h4>
                <p className="text-muted-foreground leading-relaxed">{desc}</p>
              </motion.div>
            </StaggerItem>
          ))}
        </Stagger>

        {/* What's included */}
        <div className="grid md:grid-cols-2 gap-16 mb-32">
          <FadeUp>
            <h3 className="text-sm font-mono text-primary uppercase tracking-widest mb-8">What working together looks like</h3>
            <ul className="space-y-4">
              {INCLUDED.map((item) => (
                <li key={item} className="flex items-start gap-3">
                  <CheckCircle className="w-4 h-4 text-primary mt-0.5 shrink-0" />
                  <span className="text-muted-foreground">{item}</span>
                </li>
              ))}
            </ul>
          </FadeUp>

          <FadeUp delay={0.1}>
            <h3 className="text-sm font-mono text-primary uppercase tracking-widest mb-8">What I'm not</h3>
            <div className="space-y-4 text-muted-foreground leading-relaxed">
              <p>Not a training company. I don't run courses or cohorts. I work with one leadership team, on their specific situation.</p>
              <p>Not a fractional CRO. I don't sit on your exec team or manage your managers. I advise the people who do.</p>
              <p>Not a vendor-neutral consultant. I have strong opinions formed through direct experience. If you want someone to validate what you're already doing, this isn't the right fit.</p>
            </div>
          </FadeUp>
        </div>

        {/* CTA */}
        <FadeUp>
          <div className="border border-primary/20 bg-primary/5 p-12 text-center">
            <h3 className="text-3xl font-serif font-bold mb-4">Let's have a direct conversation.</h3>
            <p className="text-muted-foreground mb-8 max-w-lg mx-auto">
              No intake form. No discovery call with a junior person first. If you want to understand whether this is the right engagement, email me directly.
            </p>
            <a
              href="mailto:mark@markreid.online"
              className="inline-flex items-center gap-2 px-8 py-4 bg-primary text-primary-foreground font-semibold hover:bg-primary/90 transition-colors"
            >
              mark@markreid.online <ArrowRight className="w-4 h-4" />
            </a>
          </div>
        </FadeUp>
      </div>
    </Layout>
  );
}
