import { Layout } from "@/components/layout/layout";
import { FadeUp, Stagger, StaggerItem } from "@/components/ui/animate";
import { motion } from "framer-motion";
import { Cpu, Zap, TrendingUp, AlertTriangle } from "lucide-react";

const VIEWS = [
  {
    icon: Zap,
    title: "AI in the sales stack",
    body: "The tools that actually move the needle are the ones that reduce admin time — note-taking, CRM hygiene, call summaries. The ones that try to replace human judgment in qualification are still mostly noise. Use AI to give your reps more time to be in front of customers, not to automate decisions they should be making themselves.",
  },
  {
    icon: TrendingUp,
    title: "Forecasting and pipeline intelligence",
    body: "Predictive pipeline tools have gotten genuinely useful. When trained on good data — clean CRM, consistent stage definitions, actual MEDDIC fields — they surface risk early. The problem is most teams don't have clean data. Fix the process before you buy the tool.",
  },
  {
    icon: Cpu,
    title: "Personalisation at scale",
    body: "AI-generated outreach is ubiquitous and buyers can spot it immediately. The irony is that the more AI floods inboxes with 'personalised' emails, the more valuable genuine personalisation becomes. The teams winning with outbound are the ones using AI for research and research only — human voice does the rest.",
  },
  {
    icon: AlertTriangle,
    title: "What to be cautious about",
    body: "Over-reliance on AI scoring that no one can explain. Automated follow-up sequences that create the illusion of pipeline without the substance of qualification. Anything that makes it easier to avoid the uncomfortable conversations that separate real deals from ghost pipeline.",
  },
];

export default function TechAI() {
  return (
    <Layout>
      <div className="container mx-auto px-6 py-24 md:py-32">
        <FadeUp className="max-w-3xl mb-20">
          <h1 className="text-sm font-mono text-primary uppercase tracking-widest mb-6">Tech & AI in Sales</h1>
          <h2 className="text-4xl md:text-6xl font-serif font-bold mb-8 text-foreground leading-tight">
            How I think about technology and AI in the sales stack.
          </h2>
          <p className="text-xl text-muted-foreground leading-relaxed font-light">
            My honest, practitioner's view on what AI and technology actually change — and what they don't — in B2B sales and revenue operations.
          </p>
        </FadeUp>

        <Stagger className="grid gap-8 max-w-5xl md:grid-cols-2" threshold={0.05}>
          {VIEWS.map(({ icon: Icon, title, body }) => (
            <StaggerItem key={title}>
              <motion.div
                className="group border border-border p-8 bg-[#0d0d14] hover:border-primary/30 transition-colors duration-300 relative overflow-hidden"
                whileHover={{ y: -2 }}
                transition={{ duration: 0.2 }}
              >
                <div className="absolute left-0 top-0 bottom-0 w-0.5 bg-primary scale-y-0 group-hover:scale-y-100 transition-transform duration-400 origin-top" />
                <div className="flex items-center gap-3 mb-6">
                  <div className="bg-primary/10 border border-primary/20 p-2.5 rounded-sm">
                    <Icon className="w-5 h-5 text-primary" />
                  </div>
                  <h3 className="font-serif font-bold text-foreground text-lg">{title}</h3>
                </div>
                <p className="text-muted-foreground leading-relaxed">{body}</p>
              </motion.div>
            </StaggerItem>
          ))}
        </Stagger>

        <FadeUp className="mt-24 max-w-3xl">
          <div className="border-l-2 border-primary pl-8 py-2">
            <p className="text-xl text-foreground font-light leading-relaxed italic font-serif">
              "The best AI application in sales isn't the one that makes your reps sound smarter — it's the one that gives them more time to be human. Every other consideration flows from that."
            </p>
            <p className="text-sm text-muted-foreground mt-4 font-mono">— Mark Reid</p>
          </div>
        </FadeUp>
      </div>
    </Layout>
  );
}
