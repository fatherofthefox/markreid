import { Layout } from "@/components/layout/layout";
import { Link } from "wouter";
import { FadeUp } from "@/components/ui/animate";

export default function NotFound() {
  return (
    <Layout>
      <div className="container mx-auto px-6 py-32 min-h-[60vh] flex flex-col items-center justify-center text-center">
        <FadeUp>
          <p className="text-7xl font-serif font-bold text-primary mb-6">404</p>
          <h1 className="text-3xl font-serif font-bold text-foreground mb-4">Page not found.</h1>
          <p className="text-muted-foreground mb-10 max-w-md">
            That page doesn't exist. Probably a dead deal — best to qualify it out and move on.
          </p>
          <Link
            href="/"
            className="inline-flex items-center gap-2 px-6 py-3 bg-primary text-primary-foreground font-semibold hover:bg-primary/90 transition-colors"
          >
            Back home
          </Link>
        </FadeUp>
      </div>
    </Layout>
  );
}
