import { Link } from "wouter";
import { Layout } from "@/components/layout/layout";
import { FadeUp, Stagger, StaggerItem } from "@/components/ui/animate";
import { motion } from "framer-motion";
import { ArrowRight, TrendingUp, Users, Target, BookOpen } from "lucide-react";

const PILLARS = [
  {
    icon: Target,
    title: "Sales Qualification",
    desc: "MEDDIC, FAINT, PEEMEES — applied in practice, not just theory. Building the habits that separate reps who close from reps who hope.",
  },
  {
    icon: TrendingUp,
    title: "Revenue Leadership",
    desc: "Building repeatable GTM motions. Forecasting that means something. Pipeline discipline that doesn't require a dedicated ops team.",
  },
  {
    icon: Users,
    title: "Team Architecture",
    desc: "Hiring sequences that build rather than accumulate headcount. Comp design that drives outcomes. Sales culture that survives a bad quarter.",
  },
  {
    icon: BookOpen,
    title: "Challenger Thinking",
    desc: "Leading with insight that reframes how buyers see their problems — before they've even heard your pitch.",
  },
];

export default function Home() {
  return (
    <Layout>
      {/* Hero */}
      <section className="relative min-h-[92vh] flex items-center overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-[#0a0a0e] via-[#0d0d16] to-[#0a0a0e]" />
        <div className="absolute inset-0 opacity-[0.04]" style={{
          backgroundImage: "radial-gradient(circle at 1px 1px, #c9a84c 1px, transparent 0)",
          backgroundSize: "48px 48px",
        }} />

        <div className="relative container mx-auto px-6 py-32">
          <FadeUp>
            <div className="inline-flex items-center gap-2 border border-primary/30 bg-primary/5 px-4 py-2 mb-10">
              <span className="w-1.5 h-1.5 rounded-full bg-primary animate-pulse" />
              <span className="text-xs font-mono text-primary uppercase tracking-widest">Sales Leadership · Advisory</span>
            </div>
          </FadeUp>

          <FadeUp delay={0.1}>
            <h1 className="text-5xl md:text-7xl lg:text-8xl font-serif font-bold leading-[1.05] tracking-tight text-foreground mb-8 max-w-4xl">
              Build teams that<br />
              <span className="text-primary italic">actually</span> close.
            </h1>
          </FadeUp>

          <FadeUp delay={0.2}>
            <p className="text-xl md:text-2xl text-muted-foreground font-light leading-relaxed max-w-2xl mb-12">
              I work with sales leaders building high-performance revenue organisations — embedding the frameworks, disciplines, and culture that separate consistent closers from lucky ones.
            </p>
          </FadeUp>

          <FadeUp delay={0.3}>
            <div className="flex flex-col sm:flex-row gap-4">
              <Link
                href="/advisory"
                className="inline-flex items-center justify-center gap-2 px-8 py-4 bg-primary text-primary-foreground font-semibold hover:bg-primary/90 transition-all duration-200 group"
              >
                Work with me
                <motion.span
                  animate={{ x: [0, 4, 0] }}
                  transition={{ duration: 1.5, repeat: Infinity, ease: "easeInOut" }}
                >
                  <ArrowRight className="w-4 h-4" />
                </motion.span>
              </Link>
              <Link
                href="/frameworks"
                className="inline-flex items-center justify-center gap-2 px-8 py-4 border border-border text-foreground font-medium hover:border-primary/40 hover:text-primary transition-all duration-200"
              >
                View frameworks
              </Link>
            </div>
          </FadeUp>
        </div>
      </section>

      {/* Credentials strip */}
      <section className="border-y border-border bg-[#0d0d14]">
        <div className="container mx-auto px-6 py-8">
          <FadeUp>
            <p className="text-center text-muted-foreground text-sm font-mono uppercase tracking-widest">
              MEDDIC · FAINT · PEEMEES · Challenger Sale · SPIN · Pipeline Excellence · Team Design
            </p>
          </FadeUp>
        </div>
      </section>

      {/* Pillars */}
      <section className="container mx-auto px-6 py-32">
        <FadeUp className="max-w-2xl mb-20">
          <h2 className="text-sm font-mono text-primary uppercase tracking-widest mb-6">What I focus on</h2>
          <h3 className="text-4xl md:text-5xl font-serif font-bold text-foreground leading-tight">
            The disciplines that determine revenue outcomes.
          </h3>
        </FadeUp>

        <Stagger className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-5xl">
          {PILLARS.map(({ icon: Icon, title, desc }) => (
            <StaggerItem key={title}>
              <div className="group border border-border p-8 hover:border-primary/30 transition-all duration-300 bg-[#0d0d14] relative overflow-hidden">
                <div className="absolute left-0 top-0 bottom-0 w-0.5 bg-primary scale-y-0 group-hover:scale-y-100 transition-transform duration-300 origin-top" />
                <Icon className="w-7 h-7 text-primary mb-6" />
                <h4 className="text-xl font-serif font-bold text-foreground mb-3">{title}</h4>
                <p className="text-muted-foreground leading-relaxed">{desc}</p>
              </div>
            </StaggerItem>
          ))}
        </Stagger>
      </section>

      {/* About teaser */}
      <section className="border-t border-border bg-[#0d0d14]">
        <div className="container mx-auto px-6 py-32 grid md:grid-cols-2 gap-16 items-center max-w-6xl">
          <FadeUp>
            <h2 className="text-sm font-mono text-primary uppercase tracking-widest mb-6">About</h2>
            <h3 className="text-4xl md:text-5xl font-serif font-bold text-foreground leading-tight mb-8">
              Built in the room, not the boardroom.
            </h3>
            <p className="text-muted-foreground leading-relaxed mb-6 text-lg">
              I've spent my career in B2B sales and revenue leadership — running teams, building GTM motions from scratch, and fixing the ones that weren't working. The frameworks I use are the ones I've personally tested under pressure, not the ones that looked good in a training deck.
            </p>
            <p className="text-muted-foreground leading-relaxed mb-10">
              I work with a small number of companies at a time. Advisory engagements are structured around outcomes, not hours.
            </p>
            <Link href="/about" className="inline-flex items-center gap-2 text-primary font-medium hover:text-primary/70 transition-colors">
              More about me <ArrowRight className="w-4 h-4" />
            </Link>
          </FadeUp>

          <FadeUp delay={0.15}>
            <div className="space-y-6">
              {[
                { num: "15+", label: "Years in B2B sales leadership" },
                { num: "7", label: "Sales frameworks deployed in practice" },
                { num: "3×", label: "Quota attainment improvement achieved" },
              ].map(({ num, label }) => (
                <div key={num} className="border border-border p-6 bg-[#0a0a0e]">
                  <div className="text-4xl font-serif font-bold text-primary mb-2">{num}</div>
                  <div className="text-muted-foreground text-sm">{label}</div>
                </div>
              ))}
            </div>
          </FadeUp>
        </div>
      </section>

      {/* CTA */}
      <section className="container mx-auto px-6 py-32">
        <FadeUp>
          <div className="border border-primary/20 bg-primary/5 p-12 md:p-16 text-center max-w-4xl mx-auto">
            <h3 className="text-4xl md:text-5xl font-serif font-bold text-foreground mb-6">
              Ready to build something that lasts?
            </h3>
            <p className="text-xl text-muted-foreground mb-10 font-light max-w-xl mx-auto">
              Advisory is selective. If you're serious about building a disciplined, high-performance revenue team, let's talk.
            </p>
            <Link
              href="/advisory"
              className="inline-flex items-center gap-2 px-10 py-4 bg-primary text-primary-foreground font-semibold hover:bg-primary/90 transition-colors text-lg"
            >
              Start a conversation <ArrowRight className="w-5 h-5" />
            </Link>
          </div>
        </FadeUp>
      </section>
    </Layout>
  );
}
