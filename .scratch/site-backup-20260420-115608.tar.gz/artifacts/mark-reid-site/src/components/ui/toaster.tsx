import { Toaster as SonnerToaster } from "sonner";

export function Toaster() {
  return (
    <SonnerToaster
      position="bottom-right"
      theme="dark"
      toastOptions={{
        style: {
          background: "#0f0f14",
          border: "1px solid #2a2a3a",
          color: "#f0ede8",
        },
      }}
    />
  );
}
